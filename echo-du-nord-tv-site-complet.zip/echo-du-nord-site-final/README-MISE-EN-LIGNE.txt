ÉCHO DU NORD TV — DOSSIER DU SITE
=================================

CONTENU
- index.html : page d’accueil
- styles.css : identité graphique responsive
- script.js : menu mobile et liens sociaux
- assets/logo-echo-du-nord.png : logo fourni
- admin/index.html + admin/config.yml : base pour le futur espace éditorial Decap CMS

IMPORTANT
Cette version est un site statique prêt à être hébergé gratuitement. Les articles de la page d’accueil sont des exemples de maquette. Le lecteur « direct » est une zone d’attente : il faut une URL de diffusion vidéo réelle pour activer le streaming. Les liens Facebook, YouTube, WhatsApp et l’adresse e-mail sont des valeurs provisoires à remplacer.

ÉTAPE 1 — PUBLIER GRATUITEMENT AVEC GITHUB PAGES
1. Créez/ouvrez un compte sur https://github.com/
2. Cliquez sur + puis New repository.
3. Nommez le dépôt par exemple echo-du-nord-tv et choisissez Public.
4. Téléversez tous les fichiers et dossiers contenus dans ce ZIP (index.html doit être à la racine du dépôt).
5. Dans le dépôt, ouvrez Settings > Pages.
6. Dans Build and deployment, choisissez Deploy from a branch, puis la branche main et le dossier /(root), puis Save.
7. Attendez la fin du déploiement. GitHub affichera l’adresse publique dans Settings > Pages, de type https://VOTRE-NOM.github.io/echo-du-nord-tv/
8. Testez le site sur téléphone et ordinateur.

ÉTAPE 2 — METTRE À JOUR LE SITE
Pour modifier le texte ou les contenus de la maquette sans CMS :
1. Dans GitHub, ouvrez index.html.
2. Cliquez sur le crayon Edit.
3. Modifiez les titres et textes; faites Commit changes.
4. Le site se met à jour automatiquement après quelques instants.
Pour ajouter des images, téléversez-les dans assets/ puis utilisez leur chemin dans le HTML.

ÉTAPE 3 — ESPACE ADMINISTRATEUR
Le dossier admin contient un squelette Decap CMS. Il ne fonctionne pas encore tout seul : un CMS a besoin d’un fournisseur d’authentification et d’un accès au dépôt.
- Le fichier admin/config.yml est configuré pour le mode Git Gateway, qui exige un hébergement et un service d’authentification compatibles.
- GitHub Pages seul ne fournit pas l’authentification nécessaire à ce tableau de bord.
- Pour un vrai espace de rédaction sans mot de passe exposé dans le code, choisissez ensuite un hébergeur/CMS compatible, configurez l’authentification et testez les rôles avant de publier.
- Ne mettez jamais de mot de passe, clé API ou jeton secret dans les fichiers du site.

ÉTAPE 4 — VIDÉOS ET DIRECT
- Vidéos YouTube : ouvrez la vidéo > Partager > Intégrer, puis insérez le code iframe fourni dans la section vidéo.
- Direct : il faut une source compatible avec un lecteur web (par exemple un flux HLS .m3u8 ou un lecteur d’hébergeur). Un lien Facebook Live/YouTube Live peut aussi être intégré lorsque les paramètres d’intégration le permettent.
- Le site ne diffuse pas lui-même la vidéo; il affiche un flux hébergé par un service externe.

À PERSONNALISER AVANT L’ANNONCE OFFICIELLE
- Les trois cartes d’actualités de démonstration
- Les vrais liens Facebook, YouTube et WhatsApp
- L’adresse e-mail officielle de la rédaction
- La source vidéo du direct
- Le nom et les coordonnées de la rédaction
- Les mentions légales et la politique de confidentialité

NOM DE DOMAINE
GitHub Pages fournit une adresse gratuite en github.io. Un nom de domaine personnalisé est généralement payant, même si certains fournisseurs peuvent proposer des promotions. Le domaine doit être acheté et configuré séparément.
